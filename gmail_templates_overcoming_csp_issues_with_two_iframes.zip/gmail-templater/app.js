InboxSDK.loadScript('https://cdnjs.cloudflare.com/ajax/libs/axios/0.18.0/axios.min.js')

helloWorldFunc = function(event) {
    event.composeView.insertTextIntoBodyAtCursor('Hello World!!!');
};

InboxSDK.load(2, 'sdk_amalb_am_b382d5f1a6').then(function(sdk){

  sdk.Compose.registerComposeViewHandler(function(composeView){

    composeView.addButton({
        title: "Templates!",
        iconUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/%28at%29.svg/240px-%28at%29.svg.png',
        onClick: function() {
            var iframe = document.createElement('iframe');
            iframe.onload = function() {
                iframe.contentWindow.postMessage("greeting", "*");
            };

            // TODO: Match the exact extension id
            // var extensionOrigin = 'chrome-extension://' + chrome.runtime.id;

            function modalMessageHandler(event) {
                if (event.origin.match(/^chrome-extension:\/\//)) {
                    //make sure that the message is coming from an extension and you can get more strict that the
                    //extension id is the same as your public extension id
                    if (event.data.match(/^template#/)) {
                        template_contents = event.data.substring(length('template#'));

                        console.log('Got template contents from iframe: ' + template_contents);
                        //modal.close();

                    }
                }
            };

            window.addEventListener('message', modalMessageHandler, false);
            iframe.src = chrome.runtime.getURL('frame.html'); //load the frame.html that is in the extension bundle

            modal = sdk.Widgets.showModalView({
                title: 'Templates to choose',
                'el': iframe,
            });

            modal.on('destroy', function() {
                window.removeEventListener('message', modalMessageHandler, false);
            });

        }
      // onClick: function(event) {
      //     sdk.Widgets.showModalView({
      //         title: 'Templates to choose',
      //         'el': `<iframe src="frame.html"></iframe>`,
      //     });
      // },

    });

  });

});
